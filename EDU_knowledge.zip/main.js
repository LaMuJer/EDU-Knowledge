// loading section starts 
    $(window).on("load" , () => {
        $('#loader').fadeOut(500 , () => {
        // $(this).remove()
        });
        document.getElementById('loader').style.zIndex = 100;
    });
// loading section ends

